﻿using System;
using System.ComponentModel;
using Microsoft.Speech.Recognition;
using System.Globalization;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;
using NAudio.Wave;
using WindowsFormsApp1.Properties;
using System.Linq;




//В планах:
/*
 * Добавить многопоточность
 * Возможность выбирать музыку голосом назвав ее
 * Улучшить распознование голоса
 * Конечно же БагоФикс
 * Добавить режим помощника конферансье
 * Режим для инвалидов(в нем все управление компьютером переносится на голос)
 * Добавить поддержку Bluetooth. MIKI выступал бы в качестве сервера
 * Взаимодействия в веб например с вк
 * Добавить спектрум анализатор(волну для отображения звука)PS Добавил но он не мой но бесплатный
 * Добавить возможность отправки данных на телефон или на другие устройства(плеер колонку и тд)
 * 
 * Подсказка для того что бы сделать выбор песни голосом
 * нужно создать базу данных которую мы будем изменять при изменении названии песни
 * потом будет осуществлять поиск по базе 
 * блин BIGDATA хорошая штука
 */



namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        private CultureInfo _culture;
        private int voly,plav, plavMinus,plavStart;
        public int kol;
        string textikl = File.ReadAllText("test.txt", Encoding.Default);

        string dopBook = "музыку";
         string next = "следующую";
         string close = "закрыть";
         string volumeM = "тише";
         string VolumeP = "громче";
         string stop = "стоп";
         string pause = "пауза";
         string To = "спасибо";

        List<string> word = new List<string>();


        Choices numbers = new Choices();
        static Label l;
        static ListBox ls;
        public List<string> numbersM = new List<string>();
        string hop;

        //Аудио метр
        private static Random rnd = new Random();
            private static double audioValueMax = 0;
            private static double audioValueLast = 0;
            private static int audioCount = 0;
            private static int RATE = 44100;
            private static int BUFFER_SAMPLES = 1024;
        
        private SpeechRecognitionEngine _sre;
        public Form1()
        {
            InitializeComponent();
            dopBook = Settings.Default["Play"].ToString();
            next = Settings.Default["Next"].ToString();
            close = Settings.Default["Close"].ToString();
            volumeM = Settings.Default["VolumeMinus"].ToString();
            VolumeP = Settings.Default["VolumePlus"].ToString();
            stop = Settings.Default["Stop"].ToString();
            pause = Settings.Default["Pause"].ToString();
            To = Settings.Default["Ta"].ToString();
            WorldMain.link = this;
            Bass_lk.InitBass(Bass_lk.xz);
            WorldMain.InputFormats();

            //Аудио метр
            try
            {
                var waveIn = new WaveInEvent
                {
                    DeviceNumber = 0,
                    WaveFormat = new WaveFormat(RATE, 1)
                };
                waveIn.DataAvailable += OnDataAvailable;
                waveIn.BufferMilliseconds = (int)(BUFFER_SAMPLES / (double)RATE * 1000.0);
                waveIn.StartRecording();
            //    waveIn.Dispose();
            }
            catch
            {
                MessageBox.Show("Подключите микрофон");
            }
        }
        //****************

     
  

          

            private void OnDataAvailable(object sender, WaveInEventArgs args)
            {

                float max = 0;

                // interpret as 16 bit audio
                for (int index = 0; index < args.BytesRecorded; index += 2)
                {
                    short sample = (short)((args.Buffer[index + 1] << 8) |
                                            args.Buffer[index + 0]);
                    var sample32 = sample / 32768f; // to floating point
                    if (sample32 < 0) sample32 = -sample32; // absolute value 
                    if (sample32 > max) max = sample32; // is this the max value?
                }

                // calculate what fraction this peak is of previous peaks
                if (max > audioValueMax)
                {
                    audioValueMax = max;
                }
                audioValueLast = max;
                audioCount += 1;
            }

        

    //****************



   

        //Действия по нажатию ОК  в openFileDialog  также здесь разделение артистов от titile
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string[] tmp = Поиск.FileNames;
            for (int i = 0; i < tmp.Length; i++)
            {
                WorldMain.Files.Add(tmp[i]);
                TagModel Tm = new TagModel(tmp[i]);
                listBox1.Items.Add(Tm.artist + "  -  " + Tm.titile);
            }

            WorldMain.Files.Add(Поиск.FileName);
            listBox1.Items.Add(WorldMain.FileNAme(Поиск.FileName));
        }

       

        //Stop
        private void button3_Click(object sender, EventArgs e)
        {
            Bass_lk.Stop();
            timer1.Enabled = false;
            trackBar1.Value = 0;
            label2.Text = "00:00:00";
        }

        //Позиция прогресс бара (он должен визуально показывает на какой секунде сейчас играет трек)
        private void timer1_Tick(object sender, EventArgs e)
        {

            label2.Text = TimeSpan.FromSeconds(Bass_lk.PositionStream(Bass_lk.stream)).ToString();
            progressBar1.Value = 0;

            if (Bass_lk.NextTrack()) //проверяем можно ли начать след трек
            {
                listBox1.SelectedIndex = WorldMain.cuerrntTrack;//меняем выделенный трек на текущую позицию

                label2.Text = TimeSpan.FromSeconds(Bass_lk.PositionStream(Bass_lk.stream)).ToString();
                label3.Text = TimeSpan.FromSeconds(Bass_lk.TimeStrem(Bass_lk.stream)).ToString();

                progressBar1.Maximum = Bass_lk.TimeStrem(Bass_lk.stream);
                trackBar1.Value = Bass_lk.PositionStream(Bass_lk.stream);
            }

            if (Bass_lk.EndTrack)//если плейлист окончен
            {
                button3_Click(this, new EventArgs());
                listBox1.SelectedIndex = WorldMain.cuerrntTrack = 0;
                Bass_lk.EndTrack = false;
            }



        }

        //Громкость + при скроле значение отображается в label4
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Bass_lk.VolumeToStream(Bass_lk.stream, trackBar1.Value);
            label4.Text = Convert.ToString(trackBar1.Value);
        }




        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                _culture = new CultureInfo("ru-RU");

                _sre = new SpeechRecognitionEngine(_culture);


                _sre.SpeechDetected += new EventHandler<SpeechDetectedEventArgs>(sr_SpeechDetected);
                _sre.RecognizeCompleted += new EventHandler<RecognizeCompletedEventArgs>(sr_RecognizeCompleted);
                _sre.SpeechHypothesized += new EventHandler<SpeechHypothesizedEventArgs>(sr_SpeechHypothesized);
                _sre.SpeechRecognitionRejected += new EventHandler<SpeechRecognitionRejectedEventArgs>(sr_SpeechRecognitionRejected);
                _sre.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(sr_SpeechRecognized);

                //Микрофон по умолчанию
                _sre.SetInputToDefaultAudioDevice();

                //Загрузка Grammar

                _sre.LoadGrammar(CreateSampleGrammar7());
                _sre.LoadGrammar(CreateSampleGrammar2());
                _sre.LoadGrammar(CreateSampleGrammar3());
                _sre.LoadGrammar(CreateSampleGrammar4());
                _sre.LoadGrammar(CreateSampleGrammar5());
                _sre.LoadGrammar(CreateSampleGrammar6());
                _sre.LoadGrammar(CreateSampleGrammar1());
                _sre.LoadGrammar(CreateSampleGrammar8());


                




                //Асинхронное распознования
                _sre.RecognizeAsync(RecognizeMode.Multiple);

                if (File.Exists("MyFile.bin"))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    using (Stream stream = new FileStream("MyFile.bin", FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        List<string> paths = (List<string>)formatter.Deserialize(stream);
                        foreach (string s in paths)
                        {
                            listBox1.Items.Add(s);
                        }
                    }
                }




            }
            catch (Exception exc)
            {
                MessageBox.Show("Ошибка: " + exc.Message);
            }

            //Трей
            notifyIcon1.BalloonTipTitle = "MIKI";
            notifyIcon1.BalloonTipText = "MIKI свернут";
            notifyIcon1.Text = "MIKI";
        }

       
        public Choices CreateSampleChoices()
        {

            var val1 = new SemanticResultValue("один");


            return new Choices(val1);
        }
       

    

        Grammar CreateSampleGrammar7()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder1 = new GrammarBuilder("музыку", SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder1.Culture = _culture;
            grammarBuilder1.Append(new SemanticResultKey("play",programs));


            return new Grammar(grammarBuilder1);

        }
        
        Grammar CreateSampleGrammar2()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder = new GrammarBuilder(stop, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder.Culture = _culture;
            grammarBuilder.Append(new SemanticResultKey("stop", programs));

            return new Grammar(grammarBuilder);
        }
        Grammar CreateSampleGrammar3()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder = new GrammarBuilder(next, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder.Culture = _culture;
            grammarBuilder.Append(new SemanticResultKey("next", programs));

            return new Grammar(grammarBuilder);
        }
        Grammar CreateSampleGrammar4()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder = new GrammarBuilder(pause, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder.Culture = _culture;
            grammarBuilder.Append(new SemanticResultKey("pause", programs));

            return new Grammar(grammarBuilder);
        }
        Grammar CreateSampleGrammar1()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder1 = new GrammarBuilder(VolumeP, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder1.Culture = _culture;
            grammarBuilder1.Append(new SemanticResultKey("volume", programs));


            return new Grammar(grammarBuilder1);

        }
        Grammar CreateSampleGrammar8()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder1 = new GrammarBuilder(volumeM, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder1.Culture = _culture;
            grammarBuilder1.Append(new SemanticResultKey("volumeMINUS", programs));


            return new Grammar(grammarBuilder1);

        }
        Grammar CreateSampleGrammar5()
        {

            var programs = CreateSampleChoices();

            var grammarBuilder = new GrammarBuilder(close, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder.Culture = _culture;
            grammarBuilder.Append(new SemanticResultKey("close", programs));

            return new Grammar(grammarBuilder);
        }
        Grammar CreateSampleGrammar6()
        {
            var programs = CreateSampleChoices();

            var grammarBuilder = new GrammarBuilder(To, SubsetMatchingMode.SubsequenceContentRequired);
            grammarBuilder.Culture = _culture;
            grammarBuilder.Append(new SemanticResultKey("spacibo", programs));

            return new Grammar(grammarBuilder);
        }
        Grammar CreateSampleGrammar10()
        {
            var programs = CreateSampleChoices();

            Choices words = new Choices(new string[] { });
            for (int i = 0; numbersM.Count > i; i++)
            {
                words.Add(numbersM.ElementAt(0));
                numbersM.RemoveAt(0);
            }
            GrammarBuilder gb = new GrammarBuilder();
            gb.Culture = _culture;
            gb.Append(words);
            gb.Append(new SemanticResultKey("vkl", programs));


            return new Grammar(gb);
        }


      


      




        private void sr_SpeechRecognitionRejected(object sender, SpeechRecognitionRejectedEventArgs e)
        {
            AppendLine("Speech Recognition Rejected: " + e.Result.Text);
        }

        private void sr_SpeechHypothesized(object sender, SpeechHypothesizedEventArgs e)
        {
            AppendLine("Speech Hypothesized: " + e.Result.Text + " (" + e.Result.Confidence + ")");
        }

        private void sr_RecognizeCompleted(object sender, RecognizeCompletedEventArgs e)
        {
            AppendLine("Recognize Completed: " + e.Result.Text);
        }

        private void sr_SpeechDetected(object sender, SpeechDetectedEventArgs e)
        {
            AppendLine("Speech Detected: audio pos " + e.AudioPosition);
        }

        private void sr_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            AppendLine("\t" + "Speech Recognized:");

            AppendLine(e.Result.Text + " (" + e.Result.Confidence + ")");

            if (e.Result.Confidence < 0.1f)
                return;

            for (var i = 0; i < e.Result.Alternates.Count; ++i)
            {
                AppendLine("\t" + "Alternate: " + e.Result.Alternates[i].Text + " (" + e.Result.Alternates[i].Confidence + ")");
            }

            for (var i = 0; i < e.Result.Words.Count; ++i)
            {
                AppendLine("\t" + "Word: " + e.Result.Words[i].Text + " (" + e.Result.Words[i].Confidence + ")");

                if (e.Result.Words[i].Confidence < 0.1f)
                    return;
            }
            //нужно было добавить что при включи пятый трек включался 5 трек(кеп)
            //пока что реализовал так но это нужно переделать,сейчас это ограничено 10 треками
            //хочется что бы было бы сколько песен столько и можно было сказать
         

            foreach (var el in e.Result.Semantics)
            {
               //  var programs = (string)el.Value.Value; Для programs (чуть выше граммаров)

                switch (el.Key)
                {

                    case "play":
                        try
                        {
                            if (e.Result.Confidence > 0.8f)
                            {
                                Bass_lk.VolumeToStream(Bass_lk.stream, 0);
                                timer5.Start();
                                string current = WorldMain.Files[listBox1.SelectedIndex];
                                WorldMain.cuerrntTrack = listBox1.SelectedIndex;
                                Bass_lk.Play(current, Bass_lk.volume);
                                label1.Text = TimeSpan.FromSeconds(Bass_lk.PositionStream(Bass_lk.stream)).ToString();
                                label2.Text = TimeSpan.FromSeconds(Bass_lk.TimeStrem(Bass_lk.stream)).ToString();
                                progressBar1.Maximum = Bass_lk.TimeStrem(Bass_lk.stream);
                                trackBar1.Value = Bass_lk.PositionStream(Bass_lk.stream);
                                timer1.Enabled = true;

                            }
                        }
                        catch
                        {
                            AppendLine("Зарузите и выбирите песню");

                        }
                        break;

                    case "stop":
                        if (e.Result.Confidence > 0.8f)
                        {
                            Bass_lk.Stop();
                            timer1.Enabled = false;
                            trackBar1.Value = 0;
                            label2.Text = "00:00";
                        }
                        break;

                    case "pause":
                        if (e.Result.Confidence > 0.8f)
                            Bass_lk.Pause();
                        break;                

                    case "volume":
                        try
                        {
                            if (e.Result.Confidence > 0.8f)
                            {
                                plav = trackBar1.Value + voly;
                                timer2.Enabled = true;
                               
                            }
                        }
                        catch
                        {
                            AppendLine("Невозможно увеличить громкость"); 
                        }

                        break;
                 
                    case "volumeMINUS":
                        try
                        {
                            if (e.Result.Confidence > 0.8f)
                            {                              
                                plavMinus = trackBar1.Value - voly;
                                timer3.Enabled = true;
                            }
                        }
                        catch
                        {
                            AppendLine("Невозможно уменьшить громкость");
                        }
                        break;
                    case "close":
                        if (e.Result.Confidence > 0.9f)
                            Close();

                        break;
                    case "vkl":
                        //Работает но хотелось бы перед название песни фразу включи
                        try
                        {
                            ls.SetSelected(ls.FindStringExact(e.Result.Text), true);
                            if (e.Result.Confidence > 0.5f)
                            {                              
                                Bass_lk.VolumeToStream(Bass_lk.stream, 0);
                                timer5.Start();
                                string current = WorldMain.Files[listBox1.SelectedIndex];
                                WorldMain.cuerrntTrack = listBox1.SelectedIndex;
                                Bass_lk.Play(current, Bass_lk.volume);
                                label1.Text = TimeSpan.FromSeconds(Bass_lk.PositionStream(Bass_lk.stream)).ToString();
                                label2.Text = TimeSpan.FromSeconds(Bass_lk.TimeStrem(Bass_lk.stream)).ToString();
                                progressBar1.Maximum = Bass_lk.TimeStrem(Bass_lk.stream);
                                trackBar1.Value = Bass_lk.PositionStream(Bass_lk.stream);
                                timer1.Enabled = true;

                            }
                        }
                        catch
                        {
                            AppendLine("Зарузите и выбирите песню");

                        }
                        break;



                    case "next":
                        if (e.Result.Confidence > 0.8f)
                        {
                            Bass_lk.Stop();
                            Bass_lk.stop = false;
                            Bass_lk.NextTrack();
                            listBox1.SelectedIndex = WorldMain.cuerrntTrack;//меняем выделенный трек на текущую позицию 

                        }
                        break;

                    case "spacibo":
                        if (e.Result.Confidence > 0.8f)
                        {
                            timer4.Start();
                           
                        }
                        break;


                }
            }
        }

        private void AppendLine(string text)
        {
            richTextBox1.AppendText(text + Environment.NewLine);
            richTextBox1.ScrollToCaret();
        }
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Show();
            notifyIcon1.Visible = false;
            WindowState = FormWindowState.Normal;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                Hide();
                notifyIcon1.Visible = true;
                notifyIcon1.ShowBalloonTip(1000);
            }
            else if (FormWindowState.Normal == this.WindowState)
            { notifyIcon1.Visible = false; }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            try
            {
                if (trackBar1.Value != plav && plav <= 100f)
                    //Был выбор либо создать 4 таймер либо нафигачить белувых переменных хз как то и это влияет на 
                    //производительность,посмотрим если будет слишком долгое срабатывание то просто поставь 4 таймер на него прикрути "старт",для плавного выкл музыки
                    //да кстати благодаря этому можно все запихнуть в 1 таймер хотя я думаю это уже слишком 
                    //если есть 4 таймер значит я лентяй
                {

                    Bass_lk.VolumeToStream(Bass_lk.stream, trackBar1.Value++);
                    label4.Text = Convert.ToString(trackBar1.Value);


                }
                else
                {
                    timer2.Enabled = false;
                }
            }
            catch
            {
                AppendLine("Невозможно увеличить громкость голосом");
            }


        }







        private void Form1_Shown(object sender, EventArgs e)
        {
            //Значения по умолчанию
            textBox1.Text = "15";
            textBox2.Text = "30";


            //Для изменения слов
            textBox3.Text = Settings.Default["Play"].ToString();
            textBox5.Text = Settings.Default["Close"].ToString();
            textBox6.Text = Settings.Default["Next"].ToString();
            textBox7.Text = Settings.Default["VolumeMinus"].ToString();
            textBox8.Text = Settings.Default["VolumePlus"].ToString();
            textBox10.Text = Settings.Default["Pause"].ToString();
            textBox4.Text = Settings.Default["Ta"].ToString();
            textBox9.Text = Settings.Default["Stop"].ToString();
            //=================================================

          



        }
        //Плавность выкл и одновременно переключения на слово "спасибо"
        private void timer4_Tick(object sender, EventArgs e)
        {
            try
            {
                if(trackBar1.Value != -1f)
                {
                    Bass_lk.VolumeToStream(Bass_lk.stream, trackBar1.Value--);
                }
                else
                {
                    timer4.Stop();
                    Bass_lk.Stop();
                    Bass_lk.stop = false;
                    Bass_lk.NextTrack();
                    listBox1.SelectedIndex = WorldMain.cuerrntTrack;
                    Bass_lk.Stop();
                }
            }
            catch
            {
                AppendLine("Не удалось уменьшить");
            }
        }
        //Плавность начала
        private void timer5_Tick(object sender, EventArgs e)
        {
            if(trackBar1.Value != plavStart)
            {
                Bass_lk.VolumeToStream(Bass_lk.stream, trackBar1.Value++);
                label4.Text = Convert.ToString(trackBar1.Value);
            }
            else
            {
                timer5.Stop();
            }
        }


        #region
        //Удаления треков из листа
        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox3.Text;
                Settings.Default["Play"] = textBox3.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox4.Text;
                Settings.Default["Ta"] = textBox4.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox5.Text;
                Settings.Default["Close"] = textBox5.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox6.Text;
                Settings.Default["Next"] = textBox6.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox7.Text;
                Settings.Default["VolumeMinus"] = textBox7.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox8.Text;
                Settings.Default["VolumePlus"] = textBox8.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox9.Text;
                Settings.Default["Stop"] = textBox9.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dopBook = textBox10.Text;
                Settings.Default["Pause"] = textBox10.Text;
                Settings.Default.Save();
            }
            catch
            {
                AppendLine("Ошибка со словами");
            }
        }
        #endregion
        //Изменение названия трека
        private void Button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox11.Text != null)
                {
                    listBox1.Items[listBox1.SelectedIndex] = textBox11.Text;
                    StringData(textBox11.Text);

                    hop = textBox11.Text;
                    Write(hop);
                    textBox11.Text = null;
                    //  word.Insert(listBox1.Items.IndexOf(word), textBox11.Text);


                }
            }
            catch
            {
                AppendLine("Что то не так с изменением названия трека");
            }
        }
        private void Write(string strip)
        {
            StreamWriter str = new StreamWriter("Data.txt");
            str.WriteLine(strip);
            numbersM.Add(strip);

            str.Dispose();
        }

        private void Read()
        {
            StreamReader strread = new StreamReader("Data.txt");
            textBox12.Text = strread.ReadLine();

            strread.Dispose();
        }

        //Для аудио метра
        private void timer6_Tick(object sender, EventArgs e)
        {           
                double frac = audioValueLast / audioValueMax;
                pictureBox_front.Width = (int)(frac * pictureBox_back.Width);
             //   richTextBox2.Text = string.Format("{0:00.00}% peak [count: {0}]", frac * 100.0, audioCount);           
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //Сохранения песен при выходе
            List<string> paths = new List<string>();
            foreach (string s in listBox1.Items)
            {
                paths.Add(s);
            }

            BinaryFormatter formatter = new BinaryFormatter();
            using (Stream stream = new FileStream("MyFile.bin", FileMode.OpenOrCreate, FileAccess.Write, FileShare.None))
            {
                formatter.Serialize(stream, paths);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            kol = listBox1.Items.Count;
            MessageBox.Show(kol.ToString());
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                Помощник fr = new Помощник();
                fr.Show();
                Hide();
            }
        }


        private void StringData(string dataStr)
        {
            MessageBox.Show(dataStr);
            
        }


        private void button9_Click(object sender, EventArgs e)
        {
            l = label10;
            ls = listBox1;

            _sre.LoadGrammar(CreateSampleGrammar10());



         


         
        }

        private void button10_Click(object sender, EventArgs e)
        {
              Read();
       /*     for(int i = 0;numbersM.Count > i;i++)
            {
                word.Add(numbersM.ElementAt(0));
                numbersM.RemoveAt(0);
            }*/
        }
        static void sre_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
         
            if (e.Result.Confidence > 0.7)
            {
                l.Text = e.Result.Text;

            }

            if (ls.Items != null)
            {
                ls.SetSelected(ls.FindStringExact(e.Result.Text), true);

                if (e.Result.Confidence > 0.8f)
                {
                    Bass_lk.VolumeToStream(Bass_lk.stream, 0);

                    string current = WorldMain.Files[ls.SelectedIndex];
                    WorldMain.cuerrntTrack = ls.SelectedIndex;
                    Bass_lk.Play(current, Bass_lk.volume);


                }
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Поиск.ShowDialog();
        }

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((listBox1.Items.Count != 0) && (listBox1.SelectedIndex != -1))//если он есть и он выделен то дальше
            {
                string current = WorldMain.Files[listBox1.SelectedIndex];

                WorldMain.cuerrntTrack = listBox1.SelectedIndex;
                Bass_lk.Play(current, Bass_lk.volume);
                label2.Text = TimeSpan.FromSeconds(Bass_lk.PositionStream(Bass_lk.stream)).ToString();
                label3.Text = TimeSpan.FromSeconds(Bass_lk.TimeStrem(Bass_lk.stream)).ToString();
                progressBar1.Maximum = Bass_lk.TimeStrem(Bass_lk.stream);
                trackBar1.Value = Bass_lk.PositionStream(Bass_lk.stream);
                timer1.Enabled = true;
            }
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bass_lk.Stop();
            timer1.Enabled = false;
            trackBar1.Value = 0;
            label2.Text = "00:00:00";
        }

        private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bass_lk.Pause();
        }



        //Плавность старта
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(textBox2.Text) >= 0)
                {
                    plavStart = Convert.ToInt32(textBox2.Text);
                }
                else
                {
                    AppendLine("Нельзя вводить отрицательные значения");
                }
            
            }
            catch
            {
                AppendLine("Введите число а не буквы");
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            try
            {
                if (trackBar1.Value != plavMinus && plavMinus >= -1f)
                {

                    Bass_lk.VolumeToStream(Bass_lk.stream, trackBar1.Value--);
                    label4.Text = Convert.ToString(trackBar1.Value);
                }
              
                else
                {
                    timer3.Enabled = false;
                }
            }
            catch
            {
                AppendLine("Невозможно уменьшить громкость голосом");
            }


             
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                voly = Convert.ToInt32(textBox1.Text);
                
            }
            catch
            {
                AppendLine("Введите число,а не символ!");
            }
        }
        
    }
}