﻿using System;
using System.Collections.Generic;
using System.Linq;
using Un4seen.Bass.AddOn.Tags;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
   public class TagModel
    {
        public int Bitrate;
        public int hz1;
        public string Channel;
        public string artist;
        public string albom;
        public string titile;
        public string year;
        //Теги недаработанно
        Dictionary<int, string> ChanalDict = new Dictionary<int, string>()
        {
            {0,"Null" },
            {1,"Mono" },
            {2,"Stereo" }
        };



        public TagModel(string fi)
        {
            TAG_INFO tagInfo = new TAG_INFO();
            tagInfo = BassTags.BASS_TAG_GetFromFile(fi);
            Channel = ChanalDict[tagInfo.channelinfo.chans];
            Bitrate = tagInfo.bitrate;
            artist = tagInfo.artist;
            hz1 = tagInfo.channelinfo.freq;
            albom = tagInfo.album;
            if (tagInfo.title == "")
                titile = WorldMain.FileNAme(fi);
            else
                titile = tagInfo.title;
            year = tagInfo.year;
        }
    }
}
