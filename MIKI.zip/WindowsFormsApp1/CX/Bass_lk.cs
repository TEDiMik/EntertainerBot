﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Un4seen.Bass;

namespace WindowsFormsApp1
{
    public static class Bass_lk
    {//сосотояние дискретизации
        public static int xz = 44100;
        //Сосотояние инициалзации
        private static bool initDefaultDevice;
        public static int stream;
        //остановлен вручную
        public static bool stop = true;

        public static bool EndTrack;


        public static int volume = 100;
        private static readonly List<int> plaginHandlers = new List<int>();



        public static int TimeStrem(int stream)
        {
            long TimeBytes = Bass.BASS_ChannelGetLength(stream);
            double Time = Bass.BASS_ChannelBytes2Seconds(stream, TimeBytes);
            return (int)Time;
        }

        public static int PositionStream(int stream)
        {
            long pos = Bass.BASS_ChannelGetPosition(stream);
            int PosSec = (int)Bass.BASS_ChannelBytes2Seconds(stream, pos);
            return PosSec;
        }


        public static void posScroll(int stream, int pos)
        {
            Bass.BASS_ChannelSetPosition(stream,(double)pos);
        }





        public static bool InitBass(int hz)
        {
            if (!initDefaultDevice)
            {
                initDefaultDevice = Bass.BASS_Init(-1, hz, BASSInit.BASS_DEVICE_DEFAULT, IntPtr.Zero);
                if (initDefaultDevice)
                {
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bass_aac.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bass_ac3.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bass_ape.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bass_mpc.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bass_tta.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bassalac.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bassflac.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\bassopus.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\basswma.dll"));
                    plaginHandlers.Add(Bass.BASS_PluginLoad(WorldMain.Patch + @"DLL\basswv.dll"));

                    int ErrorCount = 0;
                    for (int i = 0; i < plaginHandlers.Count; i++)
                        if (plaginHandlers[i] == 0)
                            ErrorCount++;
                    if (ErrorCount != 0)
                        MessageBox.Show(ErrorCount + "    не загруженно плагинов", "Ошибка", MessageBoxButtons.OK);
                    ErrorCount = 0;


                } 
            }
            return initDefaultDevice;
            
        }

        //ВОспроизведение
        public static void Play(string filename, int vol)
        {

            if (Bass.BASS_ChannelIsActive(stream) != BASSActive.BASS_ACTIVE_PAUSED)
            {
               
                Stop();
                if (InitBass(xz))
                {
                    stream = Bass.BASS_StreamCreateFile(filename, 0, 0, BASSFlag.BASS_DEFAULT);
                    if (stream != 0)
                    {
                        volume = vol;
                        Bass.BASS_ChannelSetAttribute(stream, BASSAttribute.BASS_ATTRIB_VOL, volume / 100f);
                        Bass.BASS_ChannelPlay(stream, false);
                    }
                }


                stop = false;

            }
            else
                Bass.BASS_ChannelPlay(stream, false);
        }
        public static void Pause()
        {
           if(Bass.BASS_ChannelIsActive(stream) == BASSActive.BASS_ACTIVE_PLAYING)
            Bass.BASS_ChannelPause(stream);

        }


        public static void Stop()
        {
            Bass.BASS_ChannelStop(stream);
            Bass.BASS_StreamFree(stream);
            stop = true;

        }
        //Громкость
        public static void VolumeToStream(int stream,int vol)
        {
            volume = vol;
            Bass.BASS_ChannelSetAttribute(stream, BASSAttribute.BASS_ATTRIB_VOL, vol / 100f);
        }





        public static bool NextTrack()
        {
            if((Bass.BASS_ChannelIsActive(stream) == BASSActive.BASS_ACTIVE_STOPPED) && (!stop))
            {
                if(WorldMain.Files.Count > WorldMain.cuerrntTrack + 1)
                {
                    Play(WorldMain.Files[++WorldMain.cuerrntTrack], volume);
                    EndTrack = false;//плейлист не закончен
                    return true;//возращаем true
                }
                else
                    EndTrack = true;//иначе плелист окончен 
            }
            return false;//возращаем false
        }


    }
}
