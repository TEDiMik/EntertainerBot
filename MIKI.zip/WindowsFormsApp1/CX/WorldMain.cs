﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class WorldMain
    {
        //текущая позиция трека(для автоматического переключения)
        public static int cuerrntTrack;


        public static Form1 link;
        //имена файлов
        public static List<string> Files = new List<string>();
        //путь к файлу
        public static string Patch = AppDomain.CurrentDomain.BaseDirectory;


        public static string FileNAme(string name)
        {
            string[] tp = name.Split('\\');
            return tp[tp.Length - 1];
        }


        public static void InputFormats()
        {
            link.Поиск.Filter = "Все форматы|*.mp3; *.mp4; *.tta; *.alac; *.ogg; *.opus; *.ac3; *.ape; *.mpc; *.flac; *.wma;  *.tta; *.alec; *.wv"
            + "|MPEG Audio (*.mp3)|*.mp3"
            + "|Advanced Audio Coding(*.m4a;*.m4a;)|*.m4a;*.m4a;"
            + "|OGG Vorbis Audio(*.ogg)|*.ogg"
            + "|OPUS Audioc(*.opus)|*.opus"
            + "|Dolby Digital AC3(*.ac3)|*.ac3"
            + "|Monkey Audio (*.ape)|*.ape"
            + "|MusePack (*.mpc)|*.mpc"
            + "|Free Lossless Audio codec(*.flac)|*.flac"
            + "|Windows Media Audio(*.wma)|*.wma"
            + "|True Audio(*.tta)|*.tta"
            + "|Apple Lossless Audio Codec (*.alec)|*.alec"
            + "|WavPack(*.wv)|*.wv";

        }


    }
}
